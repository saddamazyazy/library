<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Show_404 extends CI_Controller {

	public function index(){
		not_found();
	}

}

/* End of file Show_404 */
/* Location: ./application/controllers/Show_404 */