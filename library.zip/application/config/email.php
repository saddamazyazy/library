<?php

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.gmail.com';
$config['smtp_port'] = '465';
$config['smtp_timeout'] = '10';
$config['smtp_user'] = 'noreplybappedatulungagung@gmail.com';
$config['smtp_pass'] = 'YouWereMyFavoriteEntertainer';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";
$config['mailtype'] = 'html';
$config['validation'] = TRUE;