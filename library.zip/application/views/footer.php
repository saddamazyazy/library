<footer class="page-footer blue">
	<div class="footer-copyright">
		<div class="container">
			<h6>Hak Cipta &copy; <?= date("Y") ?>, e-Library "Gayatri" Bappeda Tulungagung. <a href="#" class="white-text right">REPLIKA</a></h6>
		</div>
	</div>
</footer>

<div class="fixed-action-btn">
	<a class="btn-floating btn-small blue" id="scrollToTop">
		<i class="large material-icons">keyboard_arrow_up</i>
	</a>
	<ul>
</div>