<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>REPLIKA</b>
	</div>
	<strong>Hak Cipta &copy; <?= date("Y") ?> <a href="#">E-Library</a>.</strong>
</footer>